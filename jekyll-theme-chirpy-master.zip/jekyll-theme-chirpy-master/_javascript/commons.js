import { basic, initSidebar, initTopbar } from './modules/layouts';

basic();
initSidebar();
initTopbar();
